
<img src="../Pics/MLSb-T.png" width="160">
<br><br>
<center><u><H1>Logistic Regression</H1></u></center>


```python
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
%matplotlib inline
```


```python
df=pd.read_csv("../data/iris.csv")
df.head(5)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>SepalLengthCm</th>
      <th>SepalWidthCm</th>
      <th>PetalLengthCm</th>
      <th>PetalWidthCm</th>
      <th>Species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
le.fit(['Iris-setosa','Iris-versicolor','Iris-virginica'])
y = le.transform(df['Species']) 
y
```




    array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], dtype=int64)




```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df[['PetalLengthCm','PetalWidthCm']], y, 
                                                    test_size=0.3, random_state= 0)
```


```python
# Standardize features:
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
```


```python
sc.fit(X_train)
```




    StandardScaler(copy=True, with_mean=True, with_std=True)




```python
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)
```

### Class predict:


```python
from sklearn.linear_model import LogisticRegression
```


```python
X_test_std[0,:]
```




    array([ 0.70793846,  1.50872803])




```python
logreg = LogisticRegression(C=1000.0,n_jobs=-1)
```


```python
logreg.fit(X_train_std, y_train)
```




    LogisticRegression(C=1000.0, class_weight=None, dual=False,
              fit_intercept=True, intercept_scaling=1, max_iter=100,
              multi_class='ovr', n_jobs=-1, penalty='l2', random_state=None,
              solver='liblinear', tol=0.0001, verbose=0, warm_start=False)




```python
np.round(logreg.predict_proba(X_test_std[0,:].reshape(1, -1)))
```




    array([[ 0.,  0.,  1.]])




```python
logreg.score(X_test_std, y_test)
```




    0.97777777777777775




```python
from sklearn import metrics
```


```python
print("Accuracy:", metrics.accuracy_score(y_test, logreg.predict(X_test_std)))
```

    Accuracy: 0.977777777778



```python
print("Confusion matrix:", metrics.confusion_matrix(y_test, logreg.predict(X_test_std)))
```

    Confusion matrix: [[16  0  0]
     [ 0 17  1]
     [ 0  0 11]]



```python
print("Classification report:", metrics.classification_report(y_test, logreg.predict(X_test_std)))
```

    Classification report:              precision    recall  f1-score   support
    
              0       1.00      1.00      1.00        16
              1       1.00      0.94      0.97        18
              2       0.92      1.00      0.96        11
    
    avg / total       0.98      0.98      0.98        45
    


### Avoiding overfitting via regularization:
Overfitting is a common problem in machine learning, where a model performs well on training data but does not generalize well to unseen data like test data.
C  is directly related to the regularization parameter wich is its inverse.
Decreasing the value of C means that we are increasing the regularization strength.


```python
# Lets plot different values of C:
weights, params = [], []
for n in range(-5,5):
    lr = LogisticRegression(C=10**n)
    lr.fit(X_train_std, y_train)
    #coef_ : array, shape (n_classes, n_features)
    #regression.coef_[0] corresponds to "feature1" and regression.coef_[1] corresponds to "feature2"
    #we will use class 2 vs. all classifier, coef_[1]
    weights.append(lr.coef_[1])
    params.append(10**n)
weights = np.array(weights)
plt.plot(params, weights[:,0], label='petal_length')
plt.plot(params, weights[:,1], label='petal_widht', linestyle='--')
plt.ylabel('weight coeff')
plt.xlabel('C')
plt.xscale('log')
plt.legend(loc='best')

plt.show()
```


![png](output_20_0.png)


## computing the score 5 consecutive times (with different splits each time)


```python
from sklearn.model_selection import cross_val_score
X = df[['PetalLengthCm','PetalWidthCm']]
y = df['Species']
scores = cross_val_score(logreg, X, y, cv=5, scoring='f1_macro')
scores
```




    array([ 0.96658312,  0.96658312,  0.93265993,  0.93265993,  1.        ])



## Predictions by cross-validation:


```python
from sklearn.model_selection import cross_val_predict
from sklearn import metrics
X = df[['PetalLengthCm','PetalWidthCm']]
y = df['Species']
predicted = cross_val_predict(logreg, X, y, cv=10)
metrics.accuracy_score(y, predicted) 
```




    0.95999999999999996



## Reference: 
http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

http://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_curve.html

http://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html

